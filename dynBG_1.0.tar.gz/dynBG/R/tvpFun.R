#--------  Simulate data ----------#

sptvpsim = function(n,p1,p_,p0,alpha,s2,eta2,lambda=100,tresh=0.5) {
  p = p1+p_+p0
  beta = NULL
  
  if (p1 > 0) {
    beta1 = matrix(0,n+1,p1)
    for (j in 1:p1) {
      c = sample(c(-1,1),1)*runif(1,2,4)
      beta1[1,j] = rnorm(1,c,0.01)
      for (t in 1:n) {
        while (abs(beta1[t+1,j]) < tresh) {
        beta1[t+1,j] = rnorm(1,c+0.98*(beta1[t,j]-c),sqrt(eta2))
        }
      }
    }
    beta = cbind(beta,beta1)
  }
  
  if (p_ > 0) {
    beta_ = matrix(0,n+1,p_)
    
    for (j in 1:p_) {
      
      tint = cumsum(c(1,rpois(n,lambda)))
      tint = tint[tint<n]
      tint = c(tint,n)
      
      signal = rbinom(1,1,0.5)
      
      for (id in 2:length(tint)-1) {
        
        if (signal == 0)  {
          beta_[tint[id]:tint[id+1],j] = 0
          signal = 1
        } else {
          c = sample(c(-1,1),1)*runif(1,1,1.5)
          beta_[tint[id],j] = c
          for (t in tint[id]:tint[id+1]) {
            while (abs(beta_[t+1,j]) < tresh) {
              beta_[t+1,j] = rnorm(1,c+0.98*(beta_[t,j]-c),sqrt(eta2))
            }
          }
          signal = 0
        }
      }
    }
    
    beta = cbind(beta,beta_)
  }
  
  if (p0 > 0) {
    beta0 = matrix(0,n+1,p0)
    beta = cbind(beta,beta0)
  }
  
  beta = matrix(beta,n+1,p)
  beta = beta[-1,]
  beta = matrix(beta,n,p)
  
  gamma = matrix(1,n,p)
  gamma[beta == 0] = 0
  
  y = rep(0,n)
  X = matrix(rnorm(n*p),n,p)
  
  for (t in 1:n) {
    y[t] = rnorm(1,alpha+sum(X[t,]*gamma[t,]*beta[t,]),sqrt(s2))
  }
  
  out = list(y=y,X=X,beta=t(beta),gamma=t(gamma))
  
  out
}


#--------  Get Q matrix ----------#

getQ = function(n,k0) {
  m = diag(1,n)
  diag(m)[-c(1,n)] = 2
  diag(m[-nrow(m),-1]) = -1
  diag(m[-1,-ncol(m)]) = -1
  m[1,1] = 1+1/k0
  m
}


#--------  Plot one or two matrices ----------#

matrixplot = function(m1, ynames = NULL, xdate = NULL) {
  require(ggplot2)
  require(reshape2)
  
    p = nrow(m1)
    n = ncol(m1)
    
    if (is.null(ynames)) ynames = 1:p
    if (is.null(xdate)) xdate = 1:n
    
    m.mat = data.frame(Var1=rep(xdate,p),
                    Var2=rep(1:p,each=n),
                    Value=as.vector(t(m1)[,p:1]))
    
    if (ynames[1] != "none") {
    pl = ggplot() + 
      geom_tile(data = m.mat, aes(x=Var1, y=as.numeric(Var2), fill=Value)) + ylab('') + xlab('') +
      scale_fill_gradient2(low = "red", high = "blue", mid="white",
                           midpoint = 0) +
      geom_rect(aes(ymin=0.5,ymax=p+0.5,xmin=xdate[1],xmax=xdate[n]),col="black",fill=NA,linetype='dashed') +
      theme(panel.grid = element_blank(), panel.background = element_rect(fill='white'),
            plot.background = element_rect(color=NA), axis.title.x=element_blank(), axis.title.y=element_blank(),
            text = element_text(size=20), legend.position = "right") +
      scale_y_continuous(1:p, breaks=1:p, labels=ynames) 
    }
    
    if (ynames[1] == "none") {
      pl = ggplot() + 
        geom_tile(data = m.mat, aes(x=Var1, y=as.numeric(Var2), fill=Value)) + ylab('') + xlab('') +
        scale_fill_gradient2(low = "red", high = "blue", mid="white",
                             midpoint = 0) +
        geom_rect(aes(ymin=0.5,ymax=p+0.5,xmin=xdate[1],xmax=xdate[n]),col="black",fill=NA,linetype='dashed') +
        theme(panel.grid = element_blank(), panel.background = element_rect(fill='white'),
              plot.background = element_rect(color=NA), axis.title.x=element_blank(), axis.title.y=element_blank(),
              axis.ticks.y=element_blank(),axis.text.y=element_blank(),
              text = element_text(size=20), legend.position = "right") +
        scale_y_continuous(1:p, breaks=1:p, labels=1:p)
    }
  
  plot(pl)
}

#-------------- Forecast ------------#
forecastBGTVP = function(mod,Xnew,R,homo=FALSE,const=FALSE) {
  p = nrow(mod$mu_q_beta)
  n = ncol(mod$mu_q_beta)
  
  if (!homo) sig2_sim = mod$mu_q_s2[n]
  if (homo) sig2_sim = mod$mu_q_s2
  if (const) alpha = mod$mu_q_alpha
  if (!const) alpha = mod$mu_q_alpha[n]
  
  mu_sim = alpha + sum(mod$mu_q_gamma[,n]*mod$mu_q_beta[,n]*Xnew)
  
  y_pred = rnorm(R,mu_sim,sqrt(sig2_sim))
  
  y_pred
  
}

