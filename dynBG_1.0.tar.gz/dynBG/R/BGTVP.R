#--------  Time varying regression with dependent sparsity ----------#

BGTVP = function(y,X,hyper,options=list(sv=1,smooth=0),
                 icept="TVI",Tol_Par = 0.001,Trace = 0){
  
  outMod = NULL
  
  if (icept == "CI") outMod = BGTVP_CI(y,X,hyper,options,Tol_Par,Trace)
  if (icept == "TVI") outMod = BGTVP_TVI(y,X,hyper,options,Tol_Par,Trace)
 
  if (is.null(outMod)) print("Options setting not available!")
  
  outMod
}
