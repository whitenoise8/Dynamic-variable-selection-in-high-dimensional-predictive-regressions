// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <math.h>  
#include <cmath>

using namespace std;
using namespace arma;
using namespace Rcpp;

// [[Rcpp::export]]
arma::mat invtridiag(arma::mat A) {
  int n = A.n_cols;
  
  arma::vec alpha = zeros(n);
  arma::vec gamma = zeros(n);
  
  alpha(0) = A(0,0);
  
  double a21 = A(1,0);
  for (int i = 1; i < n; i++) {
    gamma(i) = a21/alpha(i-1);
    alpha(i) = A(i,i)-a21*gamma(i);
  }
  
  arma::mat C = zeros(n,n);
  C(n-1,n-1) = 1/alpha(n-1);  
  for (int j = n-2; j > -1; j--) {
    C(n-1,j) = -a21/alpha(j)*C(n-1,j+1);
    C(j,n-1) = C(n-1,j);
  }
  for (int i = n-2; i > 0; i--) for (int j = i-1; j > -1; j--) {
    C(i,i) = 1/alpha(i)+pow(a21/alpha(i),2)*C(i+1,i+1);
    C(i,j) = -a21/alpha(j)*C(i,j+1);
    C(j,i) = C(i,j);
  }
  C(0,0) = 1/alpha(0)+pow(a21/alpha(0),2)*C(1,1);
  
  return C;
}

// [[Rcpp::export]]
arma::mat invtridiag_memo(arma::vec dvec, double od, int n) {

  arma::vec alpha = zeros(n);
  arma::vec gamma = zeros(n);
  
  alpha(0) = dvec(0);
  
  double a21 = od;
  for (int i = 1; i < n; i++) {
    gamma(i) = a21/alpha(i-1);
    alpha(i) = dvec(i)-a21*gamma(i);
  }
  
  arma::mat C = zeros(n,n);
  C(n-1,n-1) = 1/alpha(n-1);  
  for (int j = n-2; j > -1; j--) {
    C(n-1,j) = -a21/alpha(j)*C(n-1,j+1);
    C(j,n-1) = C(n-1,j);
  }
  for (int i = n-2; i > 0; i--) for (int j = i-1; j > -1; j--) {
    C(i,i) = 1/alpha(i)+pow(a21/alpha(i),2)*C(i+1,i+1);
    C(i,j) = -a21/alpha(j)*C(i,j+1);
    C(j,i) = C(i,j);
  }
  C(0,0) = 1/alpha(0)+pow(a21/alpha(0),2)*C(1,1);
  
  return C;
}
