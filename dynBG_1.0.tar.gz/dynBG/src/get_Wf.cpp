// [[Rcpp::depends(RcppArmadillo)]]
#include <RcppArmadillo.h>
#include <math.h>  
#include <cmath>

using namespace std;
using namespace arma;
using namespace Rcpp;

// [[Rcpp::export]]
arma::vec WfGet(arma::mat W, arma::mat O, arma::vec lam) {

  arma::vec Wf = W*inv_sympd(W.t()*O*W)*W.t()*lam;
  
  return Wf;
}
